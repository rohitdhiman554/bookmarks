export const SIGNUP = "SIGNUP";
export const PRODUCT_LIST = "PRODUCT_LIST";
export const SET_PRODUCTLIST = "SET_PRODUCTLIST";
