import { PRODUCT_LIST } from "../actionsTypes";

export const productList = () => {
  return {
    type: PRODUCT_LIST,
  };
};
