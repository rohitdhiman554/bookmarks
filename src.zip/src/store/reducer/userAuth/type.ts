import { signUp } from "../../actions/index";

export type Actions = ReturnType<typeof signUp>;
