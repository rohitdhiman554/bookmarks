export const ROOT = "/";
export const LOGIN = "/login";
export const HOME = "/home";
export const USERS = "/users";
